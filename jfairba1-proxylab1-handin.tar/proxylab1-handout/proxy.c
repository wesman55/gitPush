#include <stdio.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>

#define NTHREADS 100
#define SBUFSIZE  200

/* $begin sbuft */
typedef struct {
    int *buf;          /* Buffer array */
    int n;             /* Maximum number of slots */
    int front;         /* buf[(front+1)%n] is first item */
    int rear;          /* buf[rear%n] is last item */
    sem_t mutex;       /* Protects accesses to buf */
    sem_t slots;       /* Counts available slots */
    sem_t items;       /* Counts available items */
} sbuf_t;
/* $end sbuft */

/* Create an empty, bounded, shared FIFO buffer with n slots */
/* $begin sbuf_init */
void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf = calloc(n, sizeof(int));
    sp->n = n;                       /* Buffer holds max of n items */
    sp->front = sp->rear = 0;        /* Empty buffer iff front == rear */
    sem_init(&sp->mutex, 0, 1);      /* Binary semaphore for locking */
    sem_init(&sp->slots, 0, n);      /* Initially, buf has n empty slots */
    sem_init(&sp->items, 0, 0);      /* Initially, buf has zero data items */
}
/* $end sbuf_init */

/* Clean up buffer sp */
/* $begin sbuf_deinit */
void sbuf_deinit(sbuf_t *sp)
{
    free(sp->buf);
}
/* $end sbuf_deinit */

/* Insert item onto the rear of shared buffer sp */
/* $begin sbuf_insert */
void sbuf_insert(sbuf_t *sp, int item)
{
    sem_wait(&sp->slots);                          /* Wait for available slot */
    sem_wait(&sp->mutex);                          /* Lock the buffer */
    sp->buf[(++sp->rear)%(sp->n)] = item;   /* Insert the item */
    sem_post(&sp->mutex);                          /* Unlock the buffer */
    sem_post(&sp->items);                          /* Announce available item */
}
/* $end sbuf_insert */

/* Remove and return the first item from buffer sp */
/* $begin sbuf_remove */
int sbuf_remove(sbuf_t *sp)
{
    int item;
    sem_wait(&sp->items);                          /* Wait for available item */
    sem_wait(&sp->mutex);                          /* Lock the buffer */
    item = sp->buf[(++sp->front)%(sp->n)];  /* Remove the item */
    sem_post(&sp->mutex);                          /* Unlock the buffer */
    sem_post(&sp->slots);                          /* Announce available slot */
    return item;
}
/* $end sbuf_remove */
/* $end sbufc */

sbuf_t sbuf;

void doProxy(int afd);
void *thread(void *vargp);

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

int is_complete_request(const char *request) {
        int length = strlen(request);
        if (request[length-4] == '\r' && request[length-3] == '\n' && request[length-2] == '\r' && request[length-1] == '\n') {
                return 1;
        } else {
                return 0;
        }
}


int main(int argc, char *argv[]) {
	struct addrinfo hints;
        struct addrinfo *result;
        int sfd;
        int s;
        struct sockaddr_storage peer_addr;
        socklen_t peer_addr_len;
 	pthread_t tid;


	signal(SIGPIPE, SIG_IGN);
	sbuf_init(&sbuf, SBUFSIZE);
	for (int i = 0; i < NTHREADS; i++) {
                pthread_create(&tid, NULL, thread, NULL);
	}

	memset(&hints, 0, sizeof(struct addrinfo));

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	hints.ai_protocol = 0;
	hints.ai_canonname = NULL;
        hints.ai_addr = NULL;
        hints.ai_next = NULL;

	if ((s = getaddrinfo(NULL, argv[1], &hints, &result)) < 0) {
        	fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
                exit(EXIT_FAILURE);
        }

	if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                perror("Error creating socket");
                exit(EXIT_FAILURE);
        }

        if (bind(sfd, result->ai_addr, result->ai_addrlen) < 0) {
                perror("Could not bind");
                exit(EXIT_FAILURE);
        }

	if (listen(sfd, 100) < 0) {
                close(sfd);
                perror("listen error");
                exit(EXIT_FAILURE);
        }


        peer_addr_len = sizeof(struct sockaddr_storage);

	int afd;

	//freeaddrinfo(result);

	while(1) {

        	afd = accept(sfd, (struct sockaddr *) &peer_addr, &peer_addr_len);
		sbuf_insert(&sbuf, afd); /* Insert connfd in buffer */
	}

	freeaddrinfo(result);
	sbuf_deinit(&sbuf);
	return 0;
}

void doProxy(int afd) {
	ssize_t nread;

	char *buffer = calloc(MAX_OBJECT_SIZE, sizeof(char));
	memset(buffer, 0, MAX_OBJECT_SIZE);
	int totalBytes = 0;

	for (;;) {
		nread = recv(afd, buffer + totalBytes, MAX_OBJECT_SIZE, 0);
		totalBytes += nread;

		if (nread == -1) {
			printf("Didn't get any data");
                        continue;

		} 
		if (nread == 0) {
			break;
		}

		if (!memcmp(buffer + totalBytes - 4, "\r\n\r\n", 4)) {
            		break;
        	}
	}

	//printf("%s", buffer);

	char *request = calloc(6000, sizeof(char));
	char *hostname = calloc(1000, sizeof(char));
	char *port = calloc(12, sizeof(char));
	char *uri = calloc(4200, sizeof(char));

	if (is_complete_request(buffer) == 0) {
                printf("incomplete Request maybe do something who know");
      	}

	int i = 0;
	int requestTotal = 0;

        while(1) {
                if (buffer[i]== ' ') {
                        break;
                } else {
                        request[i] = buffer[i];
                }
                i++;
		requestTotal++;
        }
	i++;
	requestTotal++;


	char *http = "http://";

        char *place = strstr(buffer, http);
	if(place != NULL) {
                i = i + 7;
        }

        int j = 0;

        while(1) {
                if (buffer[i] == '/') {
                        break;
                } else if (buffer[i] == ':') {
                        break;
                } else {
                        hostname[j] = buffer[i];
                }
                i++;
                j++;
        }
        hostname[j] = '\0';
        j = 0;


        if(buffer[i] == ':') {
                i++;
                while(1) {
                        if (buffer[i] == '/') {
                                break;
                        } else {
                                port[j] = buffer[i];
                        }
                        i++;
                        j++;
                }
        } else {
                port[0] = '8';
                port[1] = '0';
                j = 2;
        }
        port[j] = '\0';

	j = 1;
	uri[0] = ' ';
	while(1) {
                if (buffer[i] == ' ') {
                        break;
                } else {
                        uri[j] = buffer[i];
                }
                i++;
                j++;
        }
        uri[j] = '\0';

	//printf("%s\n", port);

	strncat(request, uri, strlen(uri));
	strcpy(request + strlen(request), " HTTP/1.0\r\n");
	strcpy(request + strlen(request), "Host: ");
	strncat(request, hostname, strlen(hostname));
	strcpy(request + strlen(request), "\r\n");
	strcpy(request + strlen(request), user_agent_hdr);
    	strcpy(request + strlen(request), "Connection: close\r\n");
    	strcpy(request + strlen(request), "Proxy-Connection: close\r\n");

	char *token = strtok(buffer, "\n");

	while ((token = strtok(NULL, "\n")) != NULL) {
   
        	if (strstr(token, "Host:") != NULL
			        || strstr(token, "User-Agent:") != NULL	
				|| strstr(token, "Proxy-Connection:") != NULL 
				|| strstr(token, "Connection:") != NULL) {
            		continue;
		}

        	strcpy(request + strlen(request), token);
        	strcpy(request + strlen(request), "\n");
    	}

	strcpy(request + strlen(request), "\r\n");	
	
	printf("%s\n", request);


	struct addrinfo hints2;
        struct addrinfo *result2, *rp;
        int cfd, s2;

	memset(&hints2, 0, sizeof(struct addrinfo));
	hints2.ai_family = AF_UNSPEC;
	hints2.ai_socktype = SOCK_STREAM;
	hints2.ai_flags = 0;
        hints2.ai_protocol = 0;

	s2 = getaddrinfo(hostname, port, &hints2, &result2);
	if (s2 != 0) {
                fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s2));
                exit(EXIT_FAILURE);
        }

        for (rp = result2; rp != NULL; rp = rp->ai_next) {
                cfd = socket(rp->ai_family, rp->ai_socktype,
                                rp->ai_protocol);
                if (cfd == -1)
                        continue;

                if (connect(cfd, rp->ai_addr, rp->ai_addrlen) != -1)
                        break;                  /* Success */

                close(cfd);
        }

        if (rp == NULL) {               /* No address succeeded */
                fprintf(stderr, "Could not connect\n");
                exit(EXIT_FAILURE);
        }

        freeaddrinfo(result2);

	int bytesToSend = strlen(request);
	int bytesSent = 0;

	while (bytesSent < bytesToSend) {
		bytesSent = bytesSent + write(cfd, request + bytesSent, bytesToSend - bytesSent);
	}

	char *response = calloc(MAX_CACHE_SIZE, sizeof(char));
	int nread2 = 0;
	int bytesRead = 0;

	for(;;) {
		nread2 = read(cfd, response + bytesRead, MAX_OBJECT_SIZE);
		bytesRead += nread2;
		if (nread2 == -1) {
			fprintf(stderr, "Error reading frm server");
			break;
		}
		if (nread2 == 0) {
			break;
		}
	}

	//printf("%s", response);

	int bytesSent2 = 0;
	while (bytesSent2 < bytesRead) {
                bytesSent2 = bytesSent2 + write(afd, response + bytesSent2, bytesRead - bytesSent2);
        }

	free(response);
	free(request);
	free(hostname);
	free(port);
	free(uri);
	free(buffer);

	close(cfd);
}

void *thread(void *vargp) {
        pthread_detach(pthread_self());
        while (1) {
                int connfd = sbuf_remove(&sbuf); /* Remove connfd from buffer */
                doProxy(connfd);                /* Service client */
                close(connfd);
        }
}


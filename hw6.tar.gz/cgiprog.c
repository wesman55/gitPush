#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main() {
	char *query;
	query = getenv("QUERY_STRING");


	char queryOutput[1000] = "The query string is: ";
	
	strcat(queryOutput, query);
	int length = strlen(queryOutput);
	
	char buffer[5000];
	char *type = "text/plain";

	sprintf(buffer,"Content-length: %d\r\n", length);
	strcat(buffer, "Content-type: ");
	strcat(buffer, type);
	strcat (buffer, "\r\n\r\n");
    	
	strcat(buffer, queryOutput);
	strcat(buffer, "\r\n");

	printf("%s", buffer);
}

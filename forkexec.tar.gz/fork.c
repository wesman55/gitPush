#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
	int pid;
	int child_status;

	printf("Starting program; process has pid %d\n", getpid());

	FILE * fp;

	fp = fopen("fork-output.txt", "w");
	fprintf(fp, "BEFORE FORK\n");
	fflush(fp);

	int fd[2];

	pipe(fd);


	if ((pid = fork()) < 0) {
		fprintf(stderr, "Could not fork()");
		exit(1);
	}

	/* BEGIN SECTION A */

	printf("Section A;  pid %d\n", getpid());
	fprintf(fp, "SECTION A\n");
	fflush(fp);


	/* END SECTION A */
	if (pid == 0) {
		/* BEGIN SECTION B */

		printf("Section B\n");
		fprintf(fp, "SECTION B");
		fflush(fp);
		printf("Section B done sleeping\n");

		close(fd[0]);
		FILE * fd2 = fdopen(fd[1], "w");
		fputs("hello from Section B\n", fd2);
		fclose(fd2);

		char *newenviron[] = { NULL };

        	printf("Program \"%s\" has pid %d. Sleeping.\n", argv[0], getpid());

        	if (argc <= 1) {
                	printf("No program to exec.  Exiting...\n");
                	exit(0);
        	}

        	printf("Running exec of \"%s\"\n", argv[1]);
		int fileDescriptor = fileno(fp);
		dup2(fileDescriptor, 1);
        	execve(argv[1], &argv[1], newenviron);
        	printf("End of program \"%s\".\n", argv[0]);

		exit(0);

		/* END SECTION B */
	} else {
		/* BEGIN SECTION C */

		printf("Section C\n");
		fprintf(fp, "SECTION C");
		fflush(fp);

		wait(&child_status);
		printf("Section C done sleeping\n");

		close(fd[1]);
		FILE * fd2= fdopen(fd[0], "r");
		char str[100];
		fgets(str, 100, fd2);
		puts(str);
		fclose(fd2);

		exit(0);

		/* END SECTION C */
	}
	/* BEGIN SECTION D */

	printf("Section D\n");
	fprintf(fp, "SECTION D");
	fflush(fp);
	fclose(fp);

	/* END SECTION D */
}

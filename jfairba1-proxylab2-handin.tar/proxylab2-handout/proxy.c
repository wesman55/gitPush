#define MAXEVENTS 64

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <ctype.h>

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

struct request_info {
	int listenfd;
	int serverfd;
	int state;
	int first;
	char buffer[MAX_OBJECT_SIZE];
	char buffer2[MAX_OBJECT_SIZE];
	char buffer3[MAX_CACHE_SIZE];
	int numBytesRead;
	int numBytesToWriteToServer;
	int numBytesWrittenToServer;
	int numBytesReadFromServer;
	int numBytesWrittenToClient;
	char desc[100];
};

void sigint_handler(int sig);

struct epoll_event event;
struct epoll_event *events;


int main(int argc, char *argv[]) {
        struct addrinfo hints;
        struct addrinfo *result;
        int sfd;
        int s;
        
	signal(SIGINT, sigint_handler);


        memset(&hints, 0, sizeof(struct addrinfo));

        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_PASSIVE;

        hints.ai_protocol = 0;
        hints.ai_canonname = NULL;
        hints.ai_addr = NULL;
        hints.ai_next = NULL;

        if ((s = getaddrinfo(NULL, argv[1], &hints, &result)) < 0) {
                fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
                exit(EXIT_FAILURE);
        }

        if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                perror("Error creating socket");
                exit(EXIT_FAILURE);
        }

        if (bind(sfd, result->ai_addr, result->ai_addrlen) < 0) {
                perror("Could not bind");
                exit(EXIT_FAILURE);
        }

        if (listen(sfd, 100) < 0) {
                close(sfd);
                perror("listen error");
                exit(EXIT_FAILURE);
        }

	freeaddrinfo(result);

	int connfd;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;
	int efd;

	struct request_info request_event;
	struct request_info *new_request;
	struct request_info *active_event;

	size_t n; 

	if ((efd = epoll_create1(0)) < 0) {
		fprintf(stderr, "error creating epoll fd\n");
		exit(1);
	}

	request_event.listenfd = sfd;
	if (fcntl(sfd, F_SETFL, fcntl(sfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
		fprintf(stderr, "error setting socket option\n");
		exit(1);
	}

	event.data.ptr = &request_event;
	event.events = EPOLLIN | EPOLLET;
	if (epoll_ctl(efd, EPOLL_CTL_ADD, sfd, &event) < 0) {
		fprintf(stderr, "error adding event\n");
		exit(1);
	}

	events = calloc(MAXEVENTS, sizeof(event));

	while (1) {
		n = epoll_wait(efd, events, MAXEVENTS, -1);
		for (int i = 0; i < n; i++) {
			active_event = (struct request_info *)(events[i].data.ptr);

			if ((events[i].events & EPOLLERR) ||
					(events[i].events & EPOLLHUP) ||
					(events[i].events & EPOLLRDHUP)) {
				/* An error has occured on this fd */
				fprintf (stderr, "epoll error on %s\n", active_event->desc);
				close(active_event->listenfd);
				close(active_event->serverfd);
				free(active_event);
				continue;
			} else if (sfd == active_event->listenfd) {
				clientlen = sizeof(struct sockaddr_storage); 
				while (1) {
					connfd = accept(sfd, (struct sockaddr *)&clientaddr, &clientlen);
					if (connfd < 0) {
						break;
					}

					if (fcntl(connfd, F_SETFL, fcntl(connfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
						fprintf(stderr, "error setting socket option\n");
						exit(1);
					}

					new_request = (struct request_info *)malloc(sizeof(struct request_info));
					new_request->listenfd = connfd;
					//new_request->serverfd = 0;
					new_request->state = 0;
					new_request->first = 1;
					new_request->numBytesRead = 0;
        				new_request->numBytesToWriteToServer = 0;
        				new_request->numBytesWrittenToServer = 0;
        				new_request->numBytesReadFromServer = 0;
        				new_request->numBytesWrittenToClient = 0;

					event.data.ptr = new_request;
					event.events = EPOLLIN | EPOLLET;
					if (epoll_ctl(efd, EPOLL_CTL_ADD, connfd, &event) < 0) {
						fprintf(stderr, "error adding event\n");
						exit(1);
					}
				}

			} else if ((active_event->listenfd != sfd) && active_event->state == 0) {
				ssize_t nread;

				int flag = 0;

				if (active_event->first) {
					active_event->first = 0;
					memset(active_event->buffer, 0, MAX_OBJECT_SIZE);
					memset(active_event->buffer2, 0, MAX_OBJECT_SIZE);
					memset(active_event->buffer3, 0, MAX_CACHE_SIZE);

				}



        			for (;;) {
                			nread = recv(active_event->listenfd, active_event->buffer + active_event->numBytesRead, MAX_OBJECT_SIZE, 0);

                			 if (nread < 0) {
						if (!(errno == EWOULDBLOCK || errno == EAGAIN)) {
							perror("Error reading from socket");
							close(active_event->listenfd);
							free(active_event);
						}
						break;
					 }

                			if (nread == 0) {
                        			break;
                			}

					active_event->numBytesRead += nread;

                			if (!memcmp(active_event->buffer + active_event->numBytesRead - 4, "\r\n\r\n", 4)) {
						flag = 1;
                        			break;
                			}
        			}


				if (flag) {
					//printf("%s", active_event->buffer);

					char *hostname = calloc(1000, sizeof(char));
        				char *port = calloc(12, sizeof(char));
        				char *uri = calloc(4200, sizeof(char));

					int i2 = 0;

        				while(1) {
                				if (active_event->buffer[i2]== ' ') {
                        				break;
                				} else {
                        				active_event->buffer2[i2] = active_event->buffer[i2];
                				}
                				i2++;
                				active_event->numBytesToWriteToServer++;
        				}
        				i2++;
        				active_event->numBytesToWriteToServer++;


        				char *http = "http://";

        				char *place = strstr(active_event->buffer, http);
        				if(place != NULL) {
                				i2 = i2 + 7;
        				}

        				int j = 0;

					while(1) {
                				if (active_event->buffer[i2] == '/') {
                        				break;
                				} else if (active_event->buffer[i2] == ':') {
                        				break;
                				} else {
                        				hostname[j] = active_event->buffer[i2];
                				}
                				i2++;
                				j++;
        				}
        				hostname[j] = '\0';
        				j = 0;

					if (active_event->buffer[i2] == ':') {
                				i2++;
                				while(1) {
                        				if (active_event->buffer[i2] == '/') {
                                				break;
                        				} else {
                                				port[j] = active_event->buffer[i2];
                        				}
                        				i2++;
                        				j++;
                				}
        				} else {
                				port[0] = '8';
                				port[1] = '0';
                				j = 2;
        				}
        				port[j] = '\0';

        				j = 1;
        				uri[0] = ' ';
        				while(1) {
                				if (active_event->buffer[i2] == ' ') {
                        				break;
                				} else {
                        				uri[j] = active_event->buffer[i2];
                				}
                				i2++;
                				j++;
        				}
        				uri[j] = '\0';

					//strncat(active_event->buffer2, uri, strlen(uri));
					strcpy(active_event->buffer2 + strlen(active_event->buffer2), uri);
        				strcpy(active_event->buffer2 + strlen(active_event->buffer2), " HTTP/1.0\r\n");
        				strcpy(active_event->buffer2 + strlen(active_event->buffer2), "Host: ");
        				strncat(active_event->buffer2, hostname, strlen(hostname));
        				strcpy(active_event->buffer2 + strlen(active_event->buffer2), "\r\n");
        				strcpy(active_event->buffer2 + strlen(active_event->buffer2), user_agent_hdr);
        				strcpy(active_event->buffer2 + strlen(active_event->buffer2), "Connection: close\r\n");
        				strcpy(active_event->buffer2 + strlen(active_event->buffer2), "Proxy-Connection: close\r\n");

					char *token = strtok(active_event->buffer, "\n");

        				while ((token = strtok(NULL, "\n")) != NULL) {

                				if (strstr(token, "Host:") != NULL
                                				|| strstr(token, "User-Agent:") != NULL
                                				|| strstr(token, "Proxy-Connection:") != NULL
                                				|| strstr(token, "Connection:") != NULL) {
                        				continue;
                				}

                				strcpy(active_event->buffer2 + strlen(active_event->buffer2), token);
                				strcpy(active_event->buffer2 + strlen(active_event->buffer2), "\n");

        				}

					strcpy(active_event->buffer2 + strlen(active_event->buffer2), "\r\n");

					active_event->numBytesToWriteToServer = strlen(active_event->buffer2);

        				printf("%s\n", active_event->buffer2);

					struct addrinfo hints2;
        				struct addrinfo *result2, *rp;
        				int cfd, s2;

        				memset(&hints2, 0, sizeof(struct addrinfo));
        				hints2.ai_family = AF_UNSPEC;
        				hints2.ai_socktype = SOCK_STREAM;
        				hints2.ai_flags = 0;
        				hints2.ai_protocol = 0;

        				s2 = getaddrinfo(hostname, port, &hints2, &result2);
        				if (s2 != 0) {
                				fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s2));
                				exit(EXIT_FAILURE);
        				}

        				for (rp = result2; rp != NULL; rp = rp->ai_next) {
                				cfd = socket(rp->ai_family, rp->ai_socktype,
                                			rp->ai_protocol);
                				if (cfd == -1)
                        				continue;

                				if (connect(cfd, rp->ai_addr, rp->ai_addrlen) != -1)
                        				break;                  /* Success */

                				close(cfd);
        				}

        				if (rp == NULL) {               /* No address succeeded */
        				        fprintf(stderr, "Could not connect\n");
                				exit(EXIT_FAILURE);
        				}

        				freeaddrinfo(result2);

					if (fcntl(cfd, F_SETFL, fcntl(cfd, F_GETFL, 0) | O_NONBLOCK) < 0) {
                                                fprintf(stderr, "error setting socket option\n");
                                                exit(1);
                                   	}

					active_event->serverfd = cfd;
					active_event->state = 1;
      
					event.data.ptr = active_event;
                                        event.events = EPOLLOUT | EPOLLET;
                                        if (epoll_ctl(efd, EPOLL_CTL_ADD, cfd, &event) < 0) {
                                                fprintf(stderr, "error adding event\n");
                                                exit(1);
                                        }

				        free(hostname);
        				free(port);
        				free(uri);
				}
	
			} else if (active_event->state == 1) {

				int num;

				for (;;) {
					num  = write(active_event->serverfd, active_event->buffer2 + active_event->numBytesWrittenToServer,
							 active_event->numBytesToWriteToServer - active_event->numBytesWrittenToServer);
	     				if (num < 0) {
                                                if (!(errno == EWOULDBLOCK || errno == EAGAIN)) {
                                                        perror("Error reading from socket");
                                                        close(active_event->listenfd);
							close(active_event->serverfd);
                                                        free(active_event);
                                                }
                                                break;
                                         }

                                        if (num == 0) {
                                                break;
                                        }

					active_event->numBytesWrittenToServer += num;

					if(active_event->numBytesWrittenToServer >= active_event->numBytesToWriteToServer) {
						active_event->state = 2;
						
                                        	event.data.ptr = active_event;
                                        	event.events = EPOLLIN | EPOLLET;
                                        	if (epoll_ctl(efd, EPOLL_CTL_MOD, active_event->serverfd, &event) < 0) {
                                                	fprintf(stderr, "error adding event\n");
                                                	exit(1);
                                        	}
						break;
					}
				}
			} else if (active_event->state == 2) {
        			int nread2 = 0;

        			for(;;) {
                			nread2 = read(active_event->serverfd, active_event->buffer3 + active_event->numBytesReadFromServer, MAX_OBJECT_SIZE);

                                        if (nread2 < 0) {
                                                if (!(errno == EWOULDBLOCK || errno == EAGAIN)) {
                                                        perror("Error reading from server (getting response from server)");
                                                        close(active_event->listenfd);
                                                        close(active_event->serverfd);
                                                        free(active_event);
                                                }
                                                break;
                                         }


					active_event->numBytesReadFromServer += nread2;

                			if (nread2 == 0) {
                        			active_event->state = 3;
						close(active_event->serverfd);

                                                event.data.ptr = active_event;
                                                event.events = EPOLLOUT | EPOLLET;
                                                if (epoll_ctl(efd, EPOLL_CTL_MOD, active_event->listenfd, &event) < 0) {
                                                        fprintf(stderr, "error adding event\n");
                                                        exit(1);
                                                }
                                                break;

                			}
        			}
				//printf("%s", active_event->buffer3);

			} else if (active_event->state == 3) {

				int num;

                                for (;;) {
                                        num  = write(active_event->listenfd, active_event->buffer3 + active_event->numBytesWrittenToClient,
                                                         active_event->numBytesReadFromServer - active_event->numBytesWrittenToClient);
                                        if (num < 0) {
                                                if (!(errno == EWOULDBLOCK || errno == EAGAIN)) {
                                                        perror("Error reading from socket");
                                                        //close(active_event->listenfd);
                                                        //free(active_event);
                                                }
                                                break;
                                         }

                                        if (num == 0) {
                                                break;
                                        }

                                        active_event->numBytesWrittenToClient += num;

                                        if (active_event->numBytesWrittenToClient >= active_event->numBytesReadFromServer) {
                                     		close(active_event->listenfd);
						free(active_event);
                                                break;
                                        }
                                }

			} else {
				fprintf(stderr, "Something went wrong");
			}
		}
	}
	free(events);

}

void sigint_handler(int sig) {

	free(events);
}
